> [!info]  
>
> This guideline has been labeled [void](https://wiki.sei.cmu.edu//confluence/label/seccode/void) and designated for future elimination from the C Secure Coding Standard. This guideline has not been erased yet in case it contains information that might still be useful.

------------------------------------------------------------------------
[](https://www.securecoding.cert.org/confluence/display/seccode/VOID+Do+not+allow+loops+to+iterate+beyond+the+end+of+an+array?showChildren=false&showComments=false) [](https://www.securecoding.cert.org/confluence/display/seccode/99.+The+Void?showChildren=false&showComments=false) [](https://www.securecoding.cert.org/confluence/pages/viewpage.action?pageId=2981912)
## Comments:

|  |
| ----|
| I think this info is covered in STR03-C. Do not inadvertently truncate a null-terminated byte string.
                                        Posted by svoboda at Mar 31, 2009 08:23
                                     |
| Ok, I missed that. I guess I should delete this page but don't see how to. Can you delete it?
                                        Posted by stkaplan at Mar 31, 2009 12:15
                                     |

