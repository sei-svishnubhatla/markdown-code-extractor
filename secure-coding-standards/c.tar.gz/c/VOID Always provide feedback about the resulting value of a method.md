> [!info]  
>
> This guideline has been labeled [void](https://wiki.sei.cmu.edu//confluence/label/seccode/void) and designated for future elimination from the C Secure Coding Standard. This guideline has not been erased yet in case it contains information that might still be useful.

------------------------------------------------------------------------
[](https://www.securecoding.cert.org/confluence/display/seccode/VOID+Always+check+for+errors+when+using+threads?showChildren=false&showComments=false) [](https://www.securecoding.cert.org/confluence/display/seccode/99.+The+Void?showChildren=false&showComments=false) [](https://www.securecoding.cert.org/confluence/pages/viewpage.action?pageId=43319401)
## Comments:

|  |
| ----|
| It's unclear what the author of this guideline intended to say and there hasn't been any progress since October 2009. Should this page be deleted?
                                        Posted by martinsebor at Jan 18, 2010 20:24
                                     |
| Yes
                                        Posted by svoboda at Jan 19, 2010 10:10
                                     |

