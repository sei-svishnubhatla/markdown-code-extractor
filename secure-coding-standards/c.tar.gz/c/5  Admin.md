-   Page:
    [ISO-IEC WG23 PDTR 24772 Cross Reference](/confluence/display/c/ISO-IEC+WG23+PDTR+24772+Cross+Reference)
-   Page:
    [Microsoft Review Items](/confluence/display/c/Microsoft+Review+Items)
-   Page:
    [Undefined and implementation-defined behaviors not deemed ruleworthy](/confluence/display/c/Undefined+and+implementation-defined+behaviors+not+deemed+ruleworthy)
-   Page:
    [void CERT C Rules implemented in the LDRA tool suite](/confluence/display/c/void+CERT+C+Rules+implemented+in+the+LDRA+tool+suite)
