This rule is a stub.
## Risk Assessment

| Recommendation | Severity | Likelihood | Remediation Cost | Priority | Level |
| ----|----|----|----|----|----|
| ERR08-C | Medium | Probable | High | P4 | L3 |

## Related Guidelines

|  |  |
| ----|----|
| SEI CERT C++ Coding Standard | INT06-CPP. Use strtol() or a related function to convert a string token to an integer |

