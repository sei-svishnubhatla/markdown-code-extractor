> [!warning]  
>
> This page was automatically generated and should not be edited.
> [!warning]  
>
> The information on this page was provided by outside contributors and has not been verified by SEI CERT.
> [!info]  
>
> The table below can be re-ordered, by clicking column headers.

**Tool Version:** 2024.4

| 
    Checker
    | 
    Guideline
    |
| ----|----|
| C0160 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0161 | 
     FIO47-C. Use valid format strings
     |
| C0161 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0162 | 
     FIO47-C. Use valid format strings
     |
| C0162 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0163 | 
     FIO47-C. Use valid format strings
     |
| C0163 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0164 | 
     FIO47-C. Use valid format strings
     |
| C0164 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0165 | 
     FIO47-C. Use valid format strings
     |
| C0165 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0166 | 
     FIO47-C. Use valid format strings
     |
| C0166 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0167 | 
     FIO47-C. Use valid format strings
     |
| C0167 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0168 | 
     FIO47-C. Use valid format strings
     |
| C0168 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0169 | 
     FIO47-C. Use valid format strings
     |
| C0169 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0170 | 
     FIO47-C. Use valid format strings
     |
| C0170 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0171 | 
     FIO47-C. Use valid format strings
     |
| C0171 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0172 | 
     FIO47-C. Use valid format strings
     |
| C0172 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0173 | 
     FIO47-C. Use valid format strings
     |
| C0173 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0174 | 
     FIO47-C. Use valid format strings
     |
| C0174 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0175 | 
     FIO47-C. Use valid format strings
     |
| C0175 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0176 | 
     FIO47-C. Use valid format strings
     |
| C0176 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0177 | 
     FIO47-C. Use valid format strings
     |
| C0177 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0178 | 
     FIO47-C. Use valid format strings
     |
| C0178 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0179 | 
     FIO47-C. Use valid format strings
     |
| C0179 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0179 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0180 | 
     FIO47-C. Use valid format strings
     |
| C0184 | 
     FIO47-C. Use valid format strings
     |
| C0184 | 
     DCL10-C. Maintain the contract between the writer and caller of variadic functions
     |
| C0184 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0184 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0185 | 
     FIO47-C. Use valid format strings
     |
| C0185 | 
     DCL10-C. Maintain the contract between the writer and caller of variadic functions
     |
| C0185 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0185 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0186 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0186 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0190 | 
     FIO47-C. Use valid format strings
     |
| C0190 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0190 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0191 | 
     FIO47-C. Use valid format strings
     |
| C0191 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0191 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0192 | 
     FIO47-C. Use valid format strings
     |
| C0192 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0192 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0193 | 
     FIO47-C. Use valid format strings
     |
| C0193 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0193 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0194 | 
     FIO47-C. Use valid format strings
     |
| C0194 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0194 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0195 | 
     FIO47-C. Use valid format strings
     |
| C0195 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0195 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0196 | 
     FIO47-C. Use valid format strings
     |
| C0196 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0196 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0197 | 
     FIO47-C. Use valid format strings
     |
| C0197 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0197 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0198 | 
     FIO47-C. Use valid format strings
     |
| C0198 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0198 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0199 | 
     FIO47-C. Use valid format strings
     |
| C0199 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0199 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0200 | 
     FIO47-C. Use valid format strings
     |
| C0200 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0200 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0201 | 
     FIO47-C. Use valid format strings
     |
| C0201 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0201 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0202 | 
     FIO47-C. Use valid format strings
     |
| C0202 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0203 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0204 | 
     FIO47-C. Use valid format strings
     |
| C0204 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0206 | 
     FIO47-C. Use valid format strings
     |
| C0206 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0206 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0207 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0207 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0208 | 
     DCL11-C. Understand the type issues associated with variadic functions
     |
| C0208 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0209 | 
     FIO47-C. Use valid format strings
     |
| C0232 | 
     MSC40-C. Do not violate constraints
     |
| C0233 | 
     MSC40-C. Do not violate constraints
     |
| C0235 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0240 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0241 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0242 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0243 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0244 | 
     MSC40-C. Do not violate constraints
     |
| C0246 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0268 | 
     MSC40-C. Do not violate constraints
     |
| C0275 | 
     FLP00-C. Understand the limitations of floating-point numbers
     |
| C0275 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0284 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0285 | 
     MSC09-C. Character encoding: Use subset of ASCII for safety
     |
| C0286 | 
     MSC09-C. Character encoding: Use subset of ASCII for safety
     |
| C0287 | 
     MSC09-C. Character encoding: Use subset of ASCII for safety
     |
| C0288 | 
     MSC09-C. Character encoding: Use subset of ASCII for safety
     |
| C0289 | 
     MSC09-C. Character encoding: Use subset of ASCII for safety
     |
| C0299 | 
     MSC09-C. Character encoding: Use subset of ASCII for safety
     |
| C0301 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0302 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0303 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C0304 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0305 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C0306 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C0307 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0309 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C0309 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0310 | 
     EXP39-C. Do not access a variable through a pointer of an incompatible type
     |
| C0310 | 
     EXP11-C. Do not make assumptions regarding the layout of structures with bit-fields
     |
| C0311 | 
     EXP05-C. Do not cast away a const qualification
     |
| C0312 | 
     EXP32-C. Do not access a volatile object through a nonvolatile reference
     |
| C0321 | 
     MSC40-C. Do not violate constraints
     |
| C0322 | 
     MSC40-C. Do not violate constraints
     |
| C0323 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0324 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C0326 | 
     EXP36-C. Do not cast pointers into more strictly aligned pointer types
     |
| C0326 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C0327 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0337 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0338 | 
     MSC40-C. Do not violate constraints
     |
| C0339 | 
     DCL18-C. Do not begin integer constants with 0 when specifying a decimal value
     |
| C0341 | 
     PRE05-C. Understand macro replacement when concatenating tokens or performing stringification
     |
| C0342 | 
     PRE05-C. Understand macro replacement when concatenating tokens or performing stringification
     |
| C0360 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C0361 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C0362 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C0400 | 
     EXP30-C. Do not depend on the order of evaluation for side effects
     |
| C0400 | 
     EXP10-C. Do not depend on the order of evaluation of subexpressions or the order in which side effects take place
     |
| C0400 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0401 | 
     EXP30-C. Do not depend on the order of evaluation for side effects
     |
| C0401 | 
     EXP10-C. Do not depend on the order of evaluation of subexpressions or the order in which side effects take place
     |
| C0401 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0402 | 
     EXP30-C. Do not depend on the order of evaluation for side effects
     |
| C0402 | 
     EXP10-C. Do not depend on the order of evaluation of subexpressions or the order in which side effects take place
     |
| C0402 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0403 | 
     EXP30-C. Do not depend on the order of evaluation for side effects
     |
| C0403 | 
     EXP10-C. Do not depend on the order of evaluation of subexpressions or the order in which side effects take place
     |
| C0403 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0404 | 
     EXP30-C. Do not depend on the order of evaluation for side effects
     |
| C0404 | 
     EXP10-C. Do not depend on the order of evaluation of subexpressions or the order in which side effects take place
     |
| C0405 | 
     EXP30-C. Do not depend on the order of evaluation for side effects
     |
| C0405 | 
     EXP10-C. Do not depend on the order of evaluation of subexpressions or the order in which side effects take place
     |
| C0422 | 
     MSC40-C. Do not violate constraints
     |
| C0423 | 
     MSC40-C. Do not violate constraints
     |
| C0426 | 
     MSC40-C. Do not violate constraints
     |
| C0427 | 
     MSC40-C. Do not violate constraints
     |
| C0428 | 
     EXP16-C. Do not compare function pointers to constant values
     |
| C0429 | 
     MSC40-C. Do not violate constraints
     |
| C0430 | 
     MSC40-C. Do not violate constraints
     |
| C0431 | 
     MSC40-C. Do not violate constraints
     |
| C0431 | 
     DCL13-C. Declare function parameters that are pointers to values not changed by the function as const
     |
| C0431 | 
     EXP05-C. Do not cast away a const qualification
     |
| C0432 | 
     STR38-C. Do not confuse narrow and wide character strings and functions
     |
| C0432 | 
     MSC40-C. Do not violate constraints
     |
| C0432 | 
     STR04-C. Use plain char for characters in the basic character set
     |
| C0434 | 
     DCL31-C. Declare identifiers before using them
     |
| C0435 | 
     MSC40-C. Do not violate constraints
     |
| C0436 | 
     MSC40-C. Do not violate constraints
     |
| C0437 | 
     MSC40-C. Do not violate constraints
     |
| C0446 | 
     MSC40-C. Do not violate constraints
     |
| C0447 | 
     MSC40-C. Do not violate constraints
     |
| C0448 | 
     MSC40-C. Do not violate constraints
     |
| C0449 | 
     MSC40-C. Do not violate constraints
     |
| C0450 | 
     EXP35-C. Do not modify objects with temporary lifetime
     |
| C0451 | 
     MSC40-C. Do not violate constraints
     |
| C0452 | 
     MSC40-C. Do not violate constraints
     |
| C0453 | 
     MSC40-C. Do not violate constraints
     |
| C0454 | 
     MSC40-C. Do not violate constraints
     |
| C0455 | 
     EXP35-C. Do not modify objects with temporary lifetime
     |
| C0456 | 
     MSC40-C. Do not violate constraints
     |
| C0457 | 
     MSC40-C. Do not violate constraints
     |
| C0458 | 
     MSC40-C. Do not violate constraints
     |
| C0459 | 
     EXP35-C. Do not modify objects with temporary lifetime
     |
| C0460 | 
     MSC40-C. Do not violate constraints
     |
| C0461 | 
     MSC40-C. Do not violate constraints
     |
| C0462 | 
     MSC40-C. Do not violate constraints
     |
| C0463 | 
     MSC40-C. Do not violate constraints
     |
| C0464 | 
     EXP35-C. Do not modify objects with temporary lifetime
     |
| C0465 | 
     EXP35-C. Do not modify objects with temporary lifetime
     |
| C0466 | 
     MSC40-C. Do not violate constraints
     |
| C0467 | 
     MSC40-C. Do not violate constraints
     |
| C0468 | 
     MSC40-C. Do not violate constraints
     |
| C0469 | 
     MSC40-C. Do not violate constraints
     |
| C0475 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0476 | 
     MSC40-C. Do not violate constraints
     |
| C0477 | 
     MSC40-C. Do not violate constraints
     |
| C0478 | 
     MSC40-C. Do not violate constraints
     |
| C0481 | 
     MSC40-C. Do not violate constraints
     |
| C0482 | 
     MSC40-C. Do not violate constraints
     |
| C0483 | 
     MSC40-C. Do not violate constraints
     |
| C0484 | 
     MSC40-C. Do not violate constraints
     |
| C0485 | 
     MSC40-C. Do not violate constraints
     |
| C0486 | 
     MSC40-C. Do not violate constraints
     |
| C0487 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| C0487 | 
     MSC40-C. Do not violate constraints
     |
| C0488 | 
     EXP08-C. Ensure pointer arithmetic is used correctly
     |
| C0493 | 
     MSC40-C. Do not violate constraints
     |
| C0494 | 
     MSC40-C. Do not violate constraints
     |
| C0495 | 
     MSC40-C. Do not violate constraints
     |
| C0496 | 
     MSC40-C. Do not violate constraints
     |
| C0497 | 
     MSC40-C. Do not violate constraints
     |
| C0499 | 
     INT34-C. Do not shift an expression by a negative number of bits or by greater than or equal to the number of bits that exist in the operand
     |
| C0513 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| C0513 | 
     MSC40-C. Do not violate constraints
     |
| C0514 | 
     MSC40-C. Do not violate constraints
     |
| C0515 | 
     MSC40-C. Do not violate constraints
     |
| C0536 | 
     MSC40-C. Do not violate constraints
     |
| C0537 | 
     MSC40-C. Do not violate constraints
     |
| C0540 | 
     MSC40-C. Do not violate constraints
     |
| C0541 | 
     MSC40-C. Do not violate constraints
     |
| C0542 | 
     MSC40-C. Do not violate constraints
     |
| C0543 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0544 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0545 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0546 | 
     MSC40-C. Do not violate constraints
     |
| C0547 | 
     MSC40-C. Do not violate constraints
     |
| C0550 | 
     MSC40-C. Do not violate constraints
     |
| C0551 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0554 | 
     MSC40-C. Do not violate constraints
     |
| C0555 | 
     MSC40-C. Do not violate constraints
     |
| C0556 | 
     STR30-C. Do not attempt to modify string literals
     |
| C0556 | 
     MSC40-C. Do not violate constraints
     |
| C0557 | 
     MSC40-C. Do not violate constraints
     |
| C0558 | 
     MSC40-C. Do not violate constraints
     |
| C0559 | 
     MSC40-C. Do not violate constraints
     |
| C0560 | 
     MSC40-C. Do not violate constraints
     |
| C0561 | 
     MSC40-C. Do not violate constraints
     |
| C0562 | 
     EXP32-C. Do not access a volatile object through a nonvolatile reference
     |
| C0562 | 
     MSC40-C. Do not violate constraints
     |
| C0563 | 
     EXP32-C. Do not access a volatile object through a nonvolatile reference
     |
| C0563 | 
     EXP40-C. Do not modify constant objects
     |
| C0563 | 
     MSC40-C. Do not violate constraints
     |
| C0564 | 
     MSC40-C. Do not violate constraints
     |
| C0565 | 
     MSC40-C. Do not violate constraints
     |
| C0580 | 
     MSC40-C. Do not violate constraints
     |
| C0581 | 
     FLP00-C. Understand the limitations of floating-point numbers
     |
| C0581 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0582 | 
     INT35-C. Use correct integer precisions
     |
| C0588 | 
     MSC40-C. Do not violate constraints
     |
| C0589 | 
     MSC40-C. Do not violate constraints
     |
| C0590 | 
     MSC40-C. Do not violate constraints
     |
| C0591 | 
     MSC40-C. Do not violate constraints
     |
| C0601 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0602 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C0602 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0603 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C0603 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0605 | 
     MSC40-C. Do not violate constraints
     |
| C0616 | 
     MSC40-C. Do not violate constraints
     |
| C0619 | 
     MSC40-C. Do not violate constraints
     |
| C0620 | 
     MSC40-C. Do not violate constraints
     |
| C0621 | 
     MSC40-C. Do not violate constraints
     |
| C0622 | 
     MSC40-C. Do not violate constraints
     |
| C0623 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0625 | 
     DCL36-C. Do not declare an identifier with conflicting linkage classifications
     |
| C0625 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0626 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0627 | 
     MSC40-C. Do not violate constraints
     |
| C0627 | 
     DCL23-C. Guarantee that mutually visible identifiers are unique
     |
| C0628 | 
     MSC40-C. Do not violate constraints
     |
| C0629 | 
     MSC40-C. Do not violate constraints
     |
| C0630 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0631 | 
     MSC40-C. Do not violate constraints
     |
| C0632 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0633 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0634 | 
     INT12-C. Do not make assumptions about the type of a plain int bit-field when used in an expression
     |
| C0634 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0635 | 
     INT12-C. Do not make assumptions about the type of a plain int bit-field when used in an expression
     |
| C0635 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0636 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0638 | 
     MSC40-C. Do not violate constraints
     |
| C0640 | 
     MSC40-C. Do not violate constraints
     |
| C0641 | 
     MSC40-C. Do not violate constraints
     |
| C0642 | 
     MSC40-C. Do not violate constraints
     |
| C0643 | 
     MSC40-C. Do not violate constraints
     |
| C0644 | 
     MSC40-C. Do not violate constraints
     |
| C0645 | 
     MSC40-C. Do not violate constraints
     |
| C0646 | 
     MSC40-C. Do not violate constraints
     |
| C0649 | 
     MSC40-C. Do not violate constraints
     |
| C0650 | 
     MSC40-C. Do not violate constraints
     |
| C0651 | 
     MSC40-C. Do not violate constraints
     |
| C0653 | 
     MSC40-C. Do not violate constraints
     |
| C0654 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0655 | 
     MSC40-C. Do not violate constraints
     |
| C0656 | 
     MSC40-C. Do not violate constraints
     |
| C0657 | 
     MSC40-C. Do not violate constraints
     |
| C0658 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0659 | 
     MSC40-C. Do not violate constraints
     |
| C0660 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0661 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0662 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0664 | 
     MSC40-C. Do not violate constraints
     |
| C0665 | 
     MSC40-C. Do not violate constraints
     |
| C0667 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0668 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0669 | 
     MSC40-C. Do not violate constraints
     |
| C0671 | 
     MSC40-C. Do not violate constraints
     |
| C0672 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0673 | 
     EXP32-C. Do not access a volatile object through a nonvolatile reference
     |
| C0673 | 
     MSC40-C. Do not violate constraints
     |
| C0674 | 
     EXP32-C. Do not access a volatile object through a nonvolatile reference
     |
| C0674 | 
     MSC40-C. Do not violate constraints
     |
| C0674 | 
     STR04-C. Use plain char for characters in the basic character set
     |
| C0675 | 
     MSC40-C. Do not violate constraints
     |
| C0676 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0677 | 
     MSC40-C. Do not violate constraints
     |
| C0678 | 
     ARR02-C. Explicitly specify array bounds, even if implicitly defined by an initializer
     |
| C0678 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0680 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0682 | 
     MSC40-C. Do not violate constraints
     |
| C0683 | 
     MSC40-C. Do not violate constraints
     |
| C0684 | 
     MSC40-C. Do not violate constraints
     |
| C0685 | 
     MSC40-C. Do not violate constraints
     |
| C0688 | 
     ARR02-C. Explicitly specify array bounds, even if implicitly defined by an initializer
     |
| C0690 | 
     MSC40-C. Do not violate constraints
     |
| C0695 | 
     MEM02-C. Immediately cast the result of a memory allocation function call into a pointer to the allocated type
     |
| C0696 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| C0697 | 
     EXP03-C. Do not assume the size of a structure is the sum of the sizes of its members
     |
| C0698 | 
     MSC40-C. Do not violate constraints
     |
| C0699 | 
     MSC40-C. Do not violate constraints
     |
| C0699 | 
     STR04-C. Use plain char for characters in the basic character set
     |
| C0701 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| C0706 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0708 | 
     MSC40-C. Do not violate constraints
     |
| C0709 | 
     MSC40-C. Do not violate constraints
     |
| C0724 | 
     INT09-C. Ensure enumeration constants map to unique values
     |
| C0736 | 
     MSC40-C. Do not violate constraints
     |
| C0737 | 
     MSC40-C. Do not violate constraints
     |
| C0738 | 
     MSC40-C. Do not violate constraints
     |
| C0745 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0746 | 
     MSC40-C. Do not violate constraints
     |
| C0747 | 
     MSC40-C. Do not violate constraints
     |
| C0751 | 
     EXP39-C. Do not access a variable through a pointer of an incompatible type
     |
| C0751 | 
     EXP11-C. Do not make assumptions regarding the layout of structures with bit-fields
     |
| C0752 | 
     STR30-C. Do not attempt to modify string literals
     |
| C0752 | 
     STR05-C. Use pointers to const when referring to string literals
     |
| C0753 | 
     STR30-C. Do not attempt to modify string literals
     |
| C0753 | 
     STR05-C. Use pointers to const when referring to string literals
     |
| C0754 | 
     STR30-C. Do not attempt to modify string literals
     |
| C0755 | 
     MSC40-C. Do not violate constraints
     |
| C0756 | 
     MSC40-C. Do not violate constraints
     |
| C0757 | 
     MSC40-C. Do not violate constraints
     |
| C0758 | 
     MSC40-C. Do not violate constraints
     |
| C0766 | 
     MSC40-C. Do not violate constraints
     |
| C0767 | 
     MSC40-C. Do not violate constraints
     |
| C0768 | 
     MSC40-C. Do not violate constraints
     |
| C0774 | 
     MSC40-C. Do not violate constraints
     |
| C0775 | 
     MSC40-C. Do not violate constraints
     |
| C0776 | 
     DCL40-C. Do not create incompatible declarations of the same function or object
     |
| C0776 | 
     DCL23-C. Guarantee that mutually visible identifiers are unique
     |
| C0777 | 
     DCL23-C. Guarantee that mutually visible identifiers are unique
     |
| C0777 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0778 | 
     DCL40-C. Do not create incompatible declarations of the same function or object
     |
| C0778 | 
     DCL23-C. Guarantee that mutually visible identifiers are unique
     |
| C0779 | 
     DCL40-C. Do not create incompatible declarations of the same function or object
     |
| C0779 | 
     DCL23-C. Guarantee that mutually visible identifiers are unique
     |
| C0779 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0789 | 
     DCL40-C. Do not create incompatible declarations of the same function or object
     |
| C0789 | 
     DCL23-C. Guarantee that mutually visible identifiers are unique
     |
| C0790 | 
     FLP02-C. Avoid using floating-point numbers when precise computation is needed
     |
| C0791 | 
     DCL23-C. Guarantee that mutually visible identifiers are unique
     |
| C0793 | 
     DCL23-C. Guarantee that mutually visible identifiers are unique
     |
| C0795 | 
     DCL01-C. Do not reuse variable names in subscopes
     |
| C0796 | 
     DCL01-C. Do not reuse variable names in subscopes
     |
| C0801 | 
     MSC40-C. Do not violate constraints
     |
| C0801 | 
     PRE05-C. Understand macro replacement when concatenating tokens or performing stringification
     |
| C0802 | 
     MSC40-C. Do not violate constraints
     |
| C0802 | 
     PRE05-C. Understand macro replacement when concatenating tokens or performing stringification
     |
| C0803 | 
     MSC40-C. Do not violate constraints
     |
| C0803 | 
     PRE05-C. Understand macro replacement when concatenating tokens or performing stringification
     |
| C0804 | 
     MSC40-C. Do not violate constraints
     |
| C0811 | 
     MSC40-C. Do not violate constraints
     |
| C0811 | 
     PRE05-C. Understand macro replacement when concatenating tokens or performing stringification
     |
| C0813 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0814 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0821 | 
     MSC40-C. Do not violate constraints
     |
| C0821 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0830 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0831 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0834 | 
     MSC40-C. Do not violate constraints
     |
| C0835 | 
     MSC40-C. Do not violate constraints
     |
| C0836 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0837 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0840 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0844 | 
     MSC40-C. Do not violate constraints
     |
| C0845 | 
     MSC40-C. Do not violate constraints
     |
| C0848 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0851 | 
     MSC40-C. Do not violate constraints
     |
| C0852 | 
     MSC40-C. Do not violate constraints
     |
| C0853 | 
     PRE32-C. Do not use preprocessor directives in invocations of function-like macros
     |
| C0853 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0854 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0864 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0865 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0866 | 
     MSC40-C. Do not violate constraints
     |
| C0867 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0872 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0872 | 
     PRE05-C. Understand macro replacement when concatenating tokens or performing stringification
     |
| C0873 | 
     MSC40-C. Do not violate constraints
     |
| C0874 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0874 | 
     STR10-C. Do not concatenate different type of string literals
     |
| C0877 | 
     MSC40-C. Do not violate constraints
     |
| C0880 | 
     PRE05-C. Understand macro replacement when concatenating tokens or performing stringification
     |
| C0881 | 
     PRE05-C. Understand macro replacement when concatenating tokens or performing stringification
     |
| C0883 | 
     PRE06-C. Enclose header files in an include guard
     |
| C0884 | 
     PRE05-C. Understand macro replacement when concatenating tokens or performing stringification
     |
| C0885 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0887 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0888 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0899 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C0905 | 
     PRE30-C. Do not create a universal character name through concatenation
     |
| C0914 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0915 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0940 | 
     MSC40-C. Do not violate constraints
     |
| C0941 | 
     MSC40-C. Do not violate constraints
     |
| C0942 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C0943 | 
     MSC40-C. Do not violate constraints
     |
| C0944 | 
     MSC40-C. Do not violate constraints
     |
| C1001 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1002 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1003 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1006 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1008 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1012 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1014 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1015 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1019 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1020 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1021 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1022 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1023 | 
     MSC40-C. Do not violate constraints
     |
| C1024 | 
     MSC40-C. Do not violate constraints
     |
| C1025 | 
     MSC40-C. Do not violate constraints
     |
| C1026 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1028 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1029 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1033 | 
     MSC40-C. Do not violate constraints
     |
| C1034 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1035 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1036 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1037 | 
     DCL38-C. Use the correct syntax when declaring a flexible array member
     |
| C1037 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1038 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1039 | 
     DCL38-C. Use the correct syntax when declaring a flexible array member
     |
| C1041 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1042 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1043 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1044 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1045 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1046 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1047 | 
     MSC40-C. Do not violate constraints
     |
| C1048 | 
     MSC40-C. Do not violate constraints
     |
| C1050 | 
     MSC40-C. Do not violate constraints
     |
| C1051 | 
     ARR32-C. Ensure size arguments for variable length arrays are in a valid range
     |
| C1051 | 
     MEM05-C. Avoid large stack allocations
     |
| C1054 | 
     DCL21-C. Understand the storage of compound literals
     |
| C1057 | 
     EXP43-C. Avoid undefined behavior when using restrict-qualified pointers
     |
| C1061 | 
     MEM33-C.  Allocate and copy structures containing a flexible array member dynamically
     |
| C1061 | 
     MSC40-C. Do not violate constraints
     |
| C1062 | 
     MEM33-C.  Allocate and copy structures containing a flexible array member dynamically
     |
| C1062 | 
     MSC40-C. Do not violate constraints
     |
| C1063 | 
     MEM33-C.  Allocate and copy structures containing a flexible array member dynamically
     |
| C1064 | 
     MEM33-C.  Allocate and copy structures containing a flexible array member dynamically
     |
| C1069 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| C1071 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| C1073 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| C1114 | 
     CON40-C. Do not refer to an atomic variable twice in an expression
     |
| C1115 | 
     CON40-C. Do not refer to an atomic variable twice in an expression
     |
| C1116 | 
     CON40-C. Do not refer to an atomic variable twice in an expression
     |
| C1250 | 
     INT02-C. Understand integer conversion rules
     |
| C1251 | 
     INT02-C. Understand integer conversion rules
     |
| C1252 | 
     INT02-C. Understand integer conversion rules
     |
| C1253 | 
     INT02-C. Understand integer conversion rules
     |
| C1256 | 
     INT02-C. Understand integer conversion rules
     |
| C1257 | 
     INT02-C. Understand integer conversion rules
     |
| C1260 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C1260 | 
     INT02-C. Understand integer conversion rules
     |
| C1263 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C1263 | 
     INT02-C. Understand integer conversion rules
     |
| C1266 | 
     INT02-C. Understand integer conversion rules
     |
| C1272 | 
     DCL18-C. Do not begin integer constants with 0 when specifying a decimal value
     |
| C1274 | 
     INT02-C. Understand integer conversion rules
     |
| C1280 | 
     DCL16-C. Use "L," not "l," to indicate a long value
     |
| C1290 | 
     INT02-C. Understand integer conversion rules
     |
| C1291 | 
     INT02-C. Understand integer conversion rules
     |
| C1292 | 
     INT02-C. Understand integer conversion rules
     |
| C1292 | 
     INT07-C. Use only explicitly signed or unsigned char type for numeric values
     |
| C1293 | 
     INT02-C. Understand integer conversion rules
     |
| C1293 | 
     INT07-C. Use only explicitly signed or unsigned char type for numeric values
     |
| C1294 | 
     INT02-C. Understand integer conversion rules
     |
| C1295 | 
     INT02-C. Understand integer conversion rules
     |
| C1296 | 
     INT02-C. Understand integer conversion rules
     |
| C1297 | 
     INT02-C. Understand integer conversion rules
     |
| C1298 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C1298 | 
     INT02-C. Understand integer conversion rules
     |
| C1299 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C1299 | 
     INT02-C. Understand integer conversion rules
     |
| C1304 | 
     DCL07-C. Include the appropriate type information in function declarators
     |
| C1312 | 
     STR11-C. Do not specify the bound of a character array initialized with a string literal
     |
| C1331 | 
     EXP37-C. Call functions with the correct number and type of arguments
     |
| C1332 | 
     EXP37-C. Call functions with the correct number and type of arguments
     |
| C1333 | 
     EXP37-C. Call functions with the correct number and type of arguments
     |
| C1434 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C1485 | 
     FIO38-C. Do not copy a FILE object
     |
| C1490 | 
     FLP00-C. Understand the limitations of floating-point numbers
     |
| C1492 | 
     ENV30-C. Do not modify the object referenced by the return value of certain functions
     |
| C1493 | 
     ENV30-C. Do not modify the object referenced by the return value of certain functions
     |
| C1494 | 
     ENV30-C. Do not modify the object referenced by the return value of certain functions
     |
| C1500 | 
     MSC13-C. Detect and remove unused values
     |
| C1501 | 
     MSC07-C. Detect and remove dead code
     |
| C1502 | 
     MSC13-C. Detect and remove unused values
     |
| C1503 | 
     MSC07-C. Detect and remove dead code
     |
| C1504 | 
     DCL15-C. Declare file-scope objects or functions that do not need external linkage as static
     |
| C1504 | 
     DCL19-C. Minimize the scope of variables and functions
     |
| C1505 | 
     DCL19-C. Minimize the scope of variables and functions
     |
| C1509 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C1510 | 
     DCL40-C. Do not create incompatible declarations of the same function or object
     |
| C1510 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C1520 | 
     MEM05-C. Avoid large stack allocations
     |
| C1531 | 
     DCL15-C. Declare file-scope objects or functions that do not need external linkage as static
     |
| C1531 | 
     DCL19-C. Minimize the scope of variables and functions
     |
| C1532 | 
     DCL19-C. Minimize the scope of variables and functions
     |
| C1765 | 
     CON43-C. Do not allow data races in multithreaded code
     |
| C1766 | 
     CON43-C. Do not allow data races in multithreaded code
     |
| C1769 | 
     POS53-C. Do not use more than one mutex for concurrent waiting operations on a condition variable
     |
| C1770 | 
     CON43-C. Do not allow data races in multithreaded code
     |
| C1771 | 
     CON43-C. Do not allow data races in multithreaded code
     |
| C1772 | 
     CON35-C. Avoid deadlock by locking in a predefined order
     |
| C1772 | 
     POS51-C. Avoid deadlock with POSIX threads by locking in predefined order
     |
| C1773 | 
     CON35-C. Avoid deadlock by locking in a predefined order
     |
| C1773 | 
     POS51-C. Avoid deadlock with POSIX threads by locking in predefined order
     |
| C1774 | 
     CON32-C. Prevent data races when accessing bit-fields from multiple threads
     |
| C1774 | 
     POS49-C. When data must be accessed by multiple threads, provide a mutex and guarantee no adjacent data is also accessed
     |
| C1775 | 
     CON32-C. Prevent data races when accessing bit-fields from multiple threads
     |
| C1775 | 
     POS49-C. When data must be accessed by multiple threads, provide a mutex and guarantee no adjacent data is also accessed
     |
| C1776 | 
     CON39-C. Do not join or detach a thread that was previously joined or detached
     |
| C1778 | 
     CON38-C. Preserve thread safety and liveness when using condition variables
     |
| C1779 | 
     CON38-C. Preserve thread safety and liveness when using condition variables
     |
| C1780 | 
     CON30-C. Clean up thread-specific storage
     |
| C1781 | 
     CON30-C. Clean up thread-specific storage
     |
| C1782 | 
     CON30-C. Clean up thread-specific storage
     |
| C1783 | 
     CON30-C. Clean up thread-specific storage
     |
| C1784 | 
     CON30-C. Clean up thread-specific storage
     |
| C1800 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C1800 | 
     INT02-C. Understand integer conversion rules
     |
| C1802 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C1802 | 
     INT02-C. Understand integer conversion rules
     |
| C1803 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C1803 | 
     INT02-C. Understand integer conversion rules
     |
| C1804 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C1804 | 
     INT02-C. Understand integer conversion rules
     |
| C1810 | 
     INT02-C. Understand integer conversion rules
     |
| C1811 | 
     INT02-C. Understand integer conversion rules
     |
| C1812 | 
     INT02-C. Understand integer conversion rules
     |
| C1813 | 
     INT02-C. Understand integer conversion rules
     |
| C1820 | 
     INT02-C. Understand integer conversion rules
     |
| C1821 | 
     INT02-C. Understand integer conversion rules
     |
| C1822 | 
     INT02-C. Understand integer conversion rules
     |
| C1823 | 
     INT02-C. Understand integer conversion rules
     |
| C1824 | 
     INT02-C. Understand integer conversion rules
     |
| C1830 | 
     INT02-C. Understand integer conversion rules
     |
| C1831 | 
     INT02-C. Understand integer conversion rules
     |
| C1832 | 
     INT02-C. Understand integer conversion rules
     |
| C1833 | 
     INT02-C. Understand integer conversion rules
     |
| C1834 | 
     INT02-C. Understand integer conversion rules
     |
| C1840 | 
     INT02-C. Understand integer conversion rules
     |
| C1841 | 
     INT02-C. Understand integer conversion rules
     |
| C1842 | 
     INT02-C. Understand integer conversion rules
     |
| C1843 | 
     INT02-C. Understand integer conversion rules
     |
| C1844 | 
     INT02-C. Understand integer conversion rules
     |
| C1850 | 
     INT02-C. Understand integer conversion rules
     |
| C1851 | 
     INT02-C. Understand integer conversion rules
     |
| C1852 | 
     INT02-C. Understand integer conversion rules
     |
| C1853 | 
     INT02-C. Understand integer conversion rules
     |
| C1854 | 
     INT02-C. Understand integer conversion rules
     |
| C1860 | 
     INT02-C. Understand integer conversion rules
     |
| C1861 | 
     INT02-C. Understand integer conversion rules
     |
| C1862 | 
     INT02-C. Understand integer conversion rules
     |
| C1863 | 
     INT02-C. Understand integer conversion rules
     |
| C1864 | 
     INT02-C. Understand integer conversion rules
     |
| C1880 | 
     INT02-C. Understand integer conversion rules
     |
| C1881 | 
     INT02-C. Understand integer conversion rules
     |
| C1882 | 
     INT02-C. Understand integer conversion rules
     |
| C1890 | 
     INT18-C. Evaluate integer expressions in a larger size before comparing or assigning to that size
     |
| C1891 | 
     INT18-C. Evaluate integer expressions in a larger size before comparing or assigning to that size
     |
| C1892 | 
     INT18-C. Evaluate integer expressions in a larger size before comparing or assigning to that size
     |
| C1893 | 
     INT18-C. Evaluate integer expressions in a larger size before comparing or assigning to that size
     |
| C1894 | 
     INT18-C. Evaluate integer expressions in a larger size before comparing or assigning to that size
     |
| C1895 | 
     INT18-C. Evaluate integer expressions in a larger size before comparing or assigning to that size
     |
| C2000 | 
     MSC01-C. Strive for logical completeness
     |
| C2002 | 
     MSC01-C. Strive for logical completeness
     |
| C2003 | 
     MSC17-C. Finish every set of statements associated with a case label with a break statement
     |
| C2004 | 
     MSC01-C. Strive for logical completeness
     |
| C2008 | 
     DCL41-C. Do not declare variables inside a switch statement before the first case label
     |
| C2008 | 
     MSC07-C. Detect and remove dead code
     |
| C2019 | 
     MSC20-C. Do not use a switch statement to transfer control into a complex block
     |
| C2026 | 
     CON41-C. Wrap functions that can fail spuriously in a loop
     |
| C2027 | 
     CON36-C. Wrap functions that can spuriously wake up in a loop
     |
| C2028 | 
     SIG30-C. Call only asynchronous-safe functions within signal handlers
     |
| C2029 | 
     SIG31-C. Do not access shared objects in signal handlers
     |
| C2030 | 
     SIG30-C. Call only asynchronous-safe functions within signal handlers
     |
| C2030 | 
     SIG31-C. Do not access shared objects in signal handlers
     |
| C2031 | 
     ERR32-C. Do not rely on indeterminate values of errno
     |
| C2050 | 
     DCL31-C. Declare identifiers before using them
     |
| C2050 | 
     DCL07-C. Include the appropriate type information in function declarators
     |
| C2051 | 
     DCL31-C. Declare identifiers before using them
     |
| C2100 | 
     INT02-C. Understand integer conversion rules
     |
| C2101 | 
     INT02-C. Understand integer conversion rules
     |
| C2102 | 
     INT02-C. Understand integer conversion rules
     |
| C2103 | 
     INT02-C. Understand integer conversion rules
     |
| C2104 | 
     INT02-C. Understand integer conversion rules
     |
| C2105 | 
     INT02-C. Understand integer conversion rules
     |
| C2106 | 
     INT02-C. Understand integer conversion rules
     |
| C2106 | 
     STR09-C. Don't assume numeric values for expressions with type plain character
     |
| C2107 | 
     INT02-C. Understand integer conversion rules
     |
| C2107 | 
     STR09-C. Don't assume numeric values for expressions with type plain character
     |
| C2109 | 
     INT02-C. Understand integer conversion rules
     |
| C2110 | 
     INT02-C. Understand integer conversion rules
     |
| C2111 | 
     INT02-C. Understand integer conversion rules
     |
| C2112 | 
     INT02-C. Understand integer conversion rules
     |
| C2113 | 
     INT02-C. Understand integer conversion rules
     |
| C2114 | 
     INT02-C. Understand integer conversion rules
     |
| C2115 | 
     INT02-C. Understand integer conversion rules
     |
| C2116 | 
     INT02-C. Understand integer conversion rules
     |
| C2117 | 
     INT02-C. Understand integer conversion rules
     |
| C2118 | 
     INT02-C. Understand integer conversion rules
     |
| C2119 | 
     INT02-C. Understand integer conversion rules
     |
| C2120 | 
     INT02-C. Understand integer conversion rules
     |
| C2122 | 
     INT02-C. Understand integer conversion rules
     |
| C2124 | 
     INT02-C. Understand integer conversion rules
     |
| C2130 | 
     INT02-C. Understand integer conversion rules
     |
| C2132 | 
     INT02-C. Understand integer conversion rules
     |
| C2134 | 
     INT02-C. Understand integer conversion rules
     |
| C2140 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2141 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2143 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2144 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2145 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2147 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2148 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2149 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2151 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2152 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2153 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2155 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C2212 | 
     EXP19-C. Use braces for the body of an if, for, or while statement
     |
| C2500 | 
     ERR30-C. Take care when reading errno
     |
| C2501 | 
     ERR30-C. Take care when reading errno
     |
| C2502 | 
     ERR30-C. Take care when reading errno
     |
| C2503 | 
     ERR30-C. Take care when reading errno
     |
| C2547 | 
     DCL01-C. Do not reuse variable names in subscopes
     |
| C2676 | 
     FIO34-C. Distinguish between characters read from a file and EOF or WEOF
     |
| C2678 | 
     FIO34-C. Distinguish between characters read from a file and EOF or WEOF
     |
| C2790 | 
     INT34-C. Do not shift an expression by a negative number of bits or by greater than or equal to the number of bits that exist in the operand
     |
| C2800 | 
     INT32-C. Ensure that operations on signed integers do not result in overflow
     |
| C2800 | 
     INT08-C. Verify that all integer values are in range
     |
| C2830 | 
     INT33-C. Ensure that division and remainder operations do not result in divide-by-zero errors
     |
| C2840 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| C2840 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| C2840 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| C2840 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| C2850 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C2855 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C2860 | 
     INT32-C. Ensure that operations on signed integers do not result in overflow
     |
| C2877 | 
     MSC07-C. Detect and remove dead code
     |
| C2880 | 
     MSC07-C. Detect and remove dead code
     |
| C2881 | 
     MSC07-C. Detect and remove dead code
     |
| C2882 | 
     DCL41-C. Do not declare variables inside a switch statement before the first case label
     |
| C2882 | 
     MSC07-C. Detect and remove dead code
     |
| C2883 | 
     MSC07-C. Detect and remove dead code
     |
| C2890 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C2895 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C2900 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C2905 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C2910 | 
     INT30-C. Ensure that unsigned integer operations do not wrap
     |
| C2910 | 
     INT08-C. Verify that all integer values are in range
     |
| C2930 | 
     EXP08-C. Ensure pointer arithmetic is used correctly
     |
| C2931 | 
     EXP08-C. Ensure pointer arithmetic is used correctly
     |
| C2932 | 
     EXP08-C. Ensure pointer arithmetic is used correctly
     |
| C2933 | 
     EXP08-C. Ensure pointer arithmetic is used correctly
     |
| C2940 | 
     INT16-C. Do not make assumptions about representation of signed integers
     |
| C2945 | 
     INT16-C. Do not make assumptions about representation of signed integers
     |
| C3001 | 
     DCL20-C. Explicitly specify void when a function accepts no arguments
     |
| C3002 | 
     EXP37-C. Call functions with the correct number and type of arguments
     |
| C3004 | 
     EXP16-C. Do not compare function pointers to constant values
     |
| C3007 | 
     DCL20-C. Explicitly specify void when a function accepts no arguments
     |
| C3103 | 
     INT10-C. Do not assume a positive remainder when using the % operator
     |
| C3108 | 
     MSC04-C. Use comments consistently and in a readable fashion
     |
| C3109 | 
     EXP15-C. Do not place a semicolon on the same line as an if, for, or while statement
     |
| C3110 | 
     MSC12-C. Detect and remove code that has no effect or is never executed
     |
| C3112 | 
     MSC12-C. Detect and remove code that has no effect or is never executed
     |
| C3113 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C3114 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C3120 | 
     DCL06-C. Use meaningful symbolic constants to represent literal values
     |
| C3120 | 
     EXP07-C. Do not diminish the benefits of constants by assuming their values in expressions
     |
| C3121 | 
     DCL06-C. Use meaningful symbolic constants to represent literal values
     |
| C3121 | 
     EXP07-C. Do not diminish the benefits of constants by assuming their values in expressions
     |
| C3122 | 
     MSC41-C. Never hard code sensitive information
     |
| C3122 | 
     DCL06-C. Use meaningful symbolic constants to represent literal values
     |
| C3122 | 
     EXP07-C. Do not diminish the benefits of constants by assuming their values in expressions
     |
| C3123 | 
     DCL06-C. Use meaningful symbolic constants to represent literal values
     |
| C3123 | 
     EXP07-C. Do not diminish the benefits of constants by assuming their values in expressions
     |
| C3131 | 
     DCL06-C. Use meaningful symbolic constants to represent literal values
     |
| C3131 | 
     EXP07-C. Do not diminish the benefits of constants by assuming their values in expressions
     |
| C3132 | 
     DCL06-C. Use meaningful symbolic constants to represent literal values
     |
| C3132 | 
     EXP07-C. Do not diminish the benefits of constants by assuming their values in expressions
     |
| C3200 | 
     ERR33-C. Detect and handle standard library errors
     |
| C3200 | 
     POS54-C. Detect and handle POSIX library errors
     |
| C3200 | 
     EXP12-C. Do not ignore values returned by functions
     |
| C3202 | 
     MSC07-C. Detect and remove dead code
     |
| C3203 | 
     MSC07-C. Detect and remove dead code
     |
| C3203 | 
     MSC13-C. Detect and remove unused values
     |
| C3204 | 
     DCL00-C. Const-qualify immutable objects
     |
| C3205 | 
     MSC07-C. Detect and remove dead code
     |
| C3205 | 
     MSC13-C. Detect and remove unused values
     |
| C3206 | 
     MSC07-C. Detect and remove dead code
     |
| C3206 | 
     MSC13-C. Detect and remove unused values
     |
| C3207 | 
     MSC07-C. Detect and remove dead code
     |
| C3207 | 
     MSC13-C. Detect and remove unused values
     |
| C3210 | 
     DCL19-C. Minimize the scope of variables and functions
     |
| C3210 | 
     MSC07-C. Detect and remove dead code
     |
| C3217 | 
     DCL30-C. Declare objects with appropriate storage durations
     |
| C3217 | 
     DCL21-C. Understand the storage of compound literals
     |
| C3218 | 
     DCL19-C. Minimize the scope of variables and functions
     |
| C3219 | 
     MSC07-C. Detect and remove dead code
     |
| C3225 | 
     DCL30-C. Declare objects with appropriate storage durations
     |
| C3226 | 
     EXP10-C. Do not depend on the order of evaluation of subexpressions or the order in which side effects take place
     |
| C3227 | 
     DCL00-C. Const-qualify immutable objects
     |
| C3229 | 
     MSC07-C. Detect and remove dead code
     |
| C3229 | 
     MSC13-C. Detect and remove unused values
     |
| C3230 | 
     DCL30-C. Declare objects with appropriate storage durations
     |
| C3232 | 
     DCL00-C. Const-qualify immutable objects
     |
| C3234 | 
     DCL41-C. Do not declare variables inside a switch statement before the first case label
     |
| C3236 | 
     MSC40-C. Do not violate constraints
     |
| C3237 | 
     MSC40-C. Do not violate constraints
     |
| C3238 | 
     MSC40-C. Do not violate constraints
     |
| C3239 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C3244 | 
     MSC40-C. Do not violate constraints
     |
| C3305 | 
     EXP36-C. Do not cast pointers into more strictly aligned pointer types
     |
| C3305 | 
     EXP39-C. Do not access a variable through a pointer of an incompatible type
     |
| C3307 | 
     EXP44-C. Do not rely on side effects in operands to sizeof, _Alignof, or _Generic
     |
| C3307 | 
     MSC12-C. Detect and remove code that has no effect or is never executed
     |
| C3311 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C3312 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C3314 | 
     EXP45-C. Do not perform assignments in selection statements
     |
| C3319 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C3320 | 
     EXP37-C. Call functions with the correct number and type of arguments
     |
| C3326 | 
     EXP45-C. Do not perform assignments in selection statements
     |
| C3326 | 
     EXP10-C. Do not depend on the order of evaluation of subexpressions or the order in which side effects take place
     |
| C3331 | 
     DCL07-C. Include the appropriate type information in function declarators
     |
| C3334 | 
     DCL01-C. Do not reuse variable names in subscopes
     |
| C3335 | 
     DCL31-C. Declare identifiers before using them
     |
| C3335 | 
     EXP37-C. Call functions with the correct number and type of arguments
     |
| C3335 | 
     DCL07-C. Include the appropriate type information in function declarators
     |
| C3339 | 
     FLP30-C. Do not use floating-point variables as loop counters
     |
| C3339 | 
     FLP00-C. Understand the limitations of floating-point numbers
     |
| C3340 | 
     FLP30-C. Do not use floating-point variables as loop counters
     |
| C3340 | 
     FLP00-C. Understand the limitations of floating-point numbers
     |
| C3341 | 
     FLP00-C. Understand the limitations of floating-point numbers
     |
| C3342 | 
     FLP30-C. Do not use floating-point variables as loop counters
     |
| C3342 | 
     FLP00-C. Understand the limitations of floating-point numbers
     |
| C3344 | 
     EXP45-C. Do not perform assignments in selection statements
     |
| C3344 | 
     EXP46-C. Do not use a bitwise operator with a Boolean-like operand
     |
| C3344 | 
     EXP16-C. Do not compare function pointers to constant values
     |
| C3344 | 
     EXP20-C. Perform explicit tests to determine success, true and false, and equality
     |
| C3362 | 
     FLP00-C. Understand the limitations of floating-point numbers
     |
| C3383 | 
     INT30-C. Ensure that unsigned integer operations do not wrap
     |
| C3384 | 
     INT30-C. Ensure that unsigned integer operations do not wrap
     |
| C3385 | 
     INT30-C. Ensure that unsigned integer operations do not wrap
     |
| C3386 | 
     INT30-C. Ensure that unsigned integer operations do not wrap
     |
| C3389 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3390 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3391 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3392 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3392 | 
     EXP13-C. Treat relational and equality operators as if they were nonassociative
     |
| C3393 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3394 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3395 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3396 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3397 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3398 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3399 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3400 | 
     EXP00-C. Use parentheses for precedence of operation
     |
| C3401 | 
     EXP13-C. Treat relational and equality operators as if they were nonassociative
     |
| C3404 | 
     MSC07-C. Detect and remove dead code
     |
| C3404 | 
     MSC12-C. Detect and remove code that has no effect or is never executed
     |
| C3408 | 
     DCL07-C. Include the appropriate type information in function declarators
     |
| C3409 | 
     PRE02-C. Macro replacement lists should be parenthesized
     |
| C3410 | 
     PRE01-C. Use parentheses within macros around parameter names
     |
| C3412 | 
     PRE10-C. Wrap multistatement macros in a do-while loop
     |
| C3412 | 
     PRE11-C. Do not conclude macro definitions with a semicolon
     |
| C3415 | 
     EXP02-C. Be aware of the short-circuit behavior of the logical AND and OR operators
     |
| C3416 | 
     EXP45-C. Do not perform assignments in selection statements
     |
| C3422 | 
     MSC07-C. Detect and remove dead code
     |
| C3423 | 
     MSC07-C. Detect and remove dead code
     |
| C3425 | 
     MSC07-C. Detect and remove dead code
     |
| C3426 | 
     MSC12-C. Detect and remove code that has no effect or is never executed
     |
| C3427 | 
     MSC12-C. Detect and remove code that has no effect or is never executed
     |
| C3437 | 
     MSC38-C. Do not treat a predefined identifier as an object if it might only be implemented as a macro
     |
| C3437 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C3438 | 
     MSC15-C. Do not depend on undefined behavior
     |
| C3450 | 
     DCL07-C. Include the appropriate type information in function declarators
     |
| C3453 | 
     PRE00-C. Prefer inline or static functions to function-like macros
     |
| C3456 | 
     PRE12-C. Do not define unsafe macros
     |
| C3458 | 
     PRE10-C. Wrap multistatement macros in a do-while loop
     |
| C3462 | 
     PRE31-C. Avoid side effects in arguments to unsafe macros
     |
| C3463 | 
     PRE31-C. Avoid side effects in arguments to unsafe macros
     |
| C3464 | 
     PRE31-C. Avoid side effects in arguments to unsafe macros
     |
| C3465 | 
     PRE31-C. Avoid side effects in arguments to unsafe macros
     |
| C3466 | 
     PRE31-C. Avoid side effects in arguments to unsafe macros
     |
| C3467 | 
     PRE31-C. Avoid side effects in arguments to unsafe macros
     |
| C3470 | 
     MSC07-C. Detect and remove dead code
     |
| C3475 | 
     MSC38-C. Do not treat a predefined identifier as an object if it might only be implemented as a macro
     |
| C3497 | 
     MSC39-C. Do not call va_arg() on a va_list that has an indeterminate value
     |
| C3601 | 
     PRE07-C. Avoid using repeated question marks
     |
| C3664 | 
     MSC14-C. Do not introduce unnecessary platform dependencies
     |
| C3670 | 
     MEM05-C. Avoid large stack allocations
     |
| C3673 | 
     DCL00-C. Const-qualify immutable objects
     |
| C3673 | 
     DCL13-C. Declare function parameters that are pointers to values not changed by the function as const
     |
| C3674 | 
     ARR02-C. Explicitly specify array bounds, even if implicitly defined by an initializer
     |
| C3677 | 
     DCL00-C. Const-qualify immutable objects
     |
| C3677 | 
     DCL13-C. Declare function parameters that are pointers to values not changed by the function as const
     |
| C3684 | 
     ARR02-C. Explicitly specify array bounds, even if implicitly defined by an initializer
     |
| C4111 | 
     EXP13-C. Treat relational and equality operators as if they were nonassociative
     |
| C4112 | 
     EXP13-C. Treat relational and equality operators as if they were nonassociative
     |
| C4113 | 
     EXP13-C. Treat relational and equality operators as if they were nonassociative
     |
| C4116 | 
     EXP20-C. Perform explicit tests to determine success, true and false, and equality
     |
| C4117 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C4117 | 
     FLP06-C. Convert integers to floating point for floating-point operations
     |
| C4118 | 
     FLP06-C. Convert integers to floating point for floating-point operations
     |
| C4140 | 
     DCL30-C. Declare objects with appropriate storage durations
     |
| C4401 | 
     INT02-C. Understand integer conversion rules
     |
| C4401 | 
     INT07-C. Use only explicitly signed or unsigned char type for numeric values
     |
| C4402 | 
     INT02-C. Understand integer conversion rules
     |
| C4403 | 
     INT02-C. Understand integer conversion rules
     |
| C4404 | 
     INT02-C. Understand integer conversion rules
     |
| C4405 | 
     INT02-C. Understand integer conversion rules
     |
| C4410 | 
     INT02-C. Understand integer conversion rules
     |
| C4412 | 
     INT02-C. Understand integer conversion rules
     |
| C4413 | 
     STR37-C. Arguments to character-handling functions must be representable as an unsigned char
     |
| C4413 | 
     INT02-C. Understand integer conversion rules
     |
| C4414 | 
     STR37-C. Arguments to character-handling functions must be representable as an unsigned char
     |
| C4414 | 
     INT02-C. Understand integer conversion rules
     |
| C4415 | 
     INT02-C. Understand integer conversion rules
     |
| C4420 | 
     INT02-C. Understand integer conversion rules
     |
| C4421 | 
     INT02-C. Understand integer conversion rules
     |
| C4421 | 
     INT07-C. Use only explicitly signed or unsigned char type for numeric values
     |
| C4422 | 
     INT02-C. Understand integer conversion rules
     |
| C4423 | 
     INT02-C. Understand integer conversion rules
     |
| C4424 | 
     INT02-C. Understand integer conversion rules
     |
| C4425 | 
     INT02-C. Understand integer conversion rules
     |
| C4430 | 
     INT02-C. Understand integer conversion rules
     |
| C4431 | 
     INT02-C. Understand integer conversion rules
     |
| C4431 | 
     INT07-C. Use only explicitly signed or unsigned char type for numeric values
     |
| C4432 | 
     INT02-C. Understand integer conversion rules
     |
| C4434 | 
     INT02-C. Understand integer conversion rules
     |
| C4435 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C4435 | 
     INT02-C. Understand integer conversion rules
     |
| C4436 | 
     INT02-C. Understand integer conversion rules
     |
| C4437 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C4437 | 
     INT02-C. Understand integer conversion rules
     |
| C4440 | 
     INT02-C. Understand integer conversion rules
     |
| C4441 | 
     INT02-C. Understand integer conversion rules
     |
| C4441 | 
     INT07-C. Use only explicitly signed or unsigned char type for numeric values
     |
| C4442 | 
     INT02-C. Understand integer conversion rules
     |
| C4443 | 
     INT02-C. Understand integer conversion rules
     |
| C4445 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C4445 | 
     INT02-C. Understand integer conversion rules
     |
| C4446 | 
     INT02-C. Understand integer conversion rules
     |
| C4447 | 
     INT02-C. Understand integer conversion rules
     |
| C4450 | 
     FLP34-C. Ensure that floating-point conversions are within range of the new type
     |
| C4451 | 
     FLP34-C. Ensure that floating-point conversions are within range of the new type
     |
| C4451 | 
     INT07-C. Use only explicitly signed or unsigned char type for numeric values
     |
| C4452 | 
     FLP34-C. Ensure that floating-point conversions are within range of the new type
     |
| C4453 | 
     FLP34-C. Ensure that floating-point conversions are within range of the new type
     |
| C4454 | 
     FLP34-C. Ensure that floating-point conversions are within range of the new type
     |
| C4460 | 
     INT02-C. Understand integer conversion rules
     |
| C4461 | 
     INT02-C. Understand integer conversion rules
     |
| C4462 | 
     FLP34-C. Ensure that floating-point conversions are within range of the new type
     |
| C4463 | 
     INT02-C. Understand integer conversion rules
     |
| C4464 | 
     INT02-C. Understand integer conversion rules
     |
| C4465 | 
     FLP34-C. Ensure that floating-point conversions are within range of the new type
     |
| C4470 | 
     INT02-C. Understand integer conversion rules
     |
| C4471 | 
     INT02-C. Understand integer conversion rules
     |
| C4480 | 
     INT02-C. Understand integer conversion rules
     |
| C4481 | 
     INT02-C. Understand integer conversion rules
     |
| C4490 | 
     INT18-C. Evaluate integer expressions in a larger size before comparing or assigning to that size
     |
| C4491 | 
     INT18-C. Evaluate integer expressions in a larger size before comparing or assigning to that size
     |
| C4492 | 
     INT18-C. Evaluate integer expressions in a larger size before comparing or assigning to that size
     |
| C4502 | 
     EXP46-C. Do not use a bitwise operator with a Boolean-like operand
     |
| C4532 | 
     INT13-C. Use bitwise operators only on unsigned operands
     |
| C4533 | 
     INT13-C. Use bitwise operators only on unsigned operands
     |
| C4534 | 
     INT13-C. Use bitwise operators only on unsigned operands
     |
| C4543 | 
     INT13-C. Use bitwise operators only on unsigned operands
     |
| C4544 | 
     INT13-C. Use bitwise operators only on unsigned operands
     |
| C4600 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4601 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4602 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4603 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4604 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4605 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4606 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4607 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4608 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4620 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4621 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4622 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4623 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4624 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4640 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4641 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4642 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4643 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4644 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C4645 | 
     DCL37-C. Do not declare or define a reserved identifier
     |
| C5001 | 
     PRE04-C. Do not reuse a standard header file name
     |
| C5002 | 
     PRE08-C. Guarantee that header file names are unique
     |
| C5003 | 
     PRE09-C. Do not replace secure functions with deprecated or obsolescent functions
     |
| C5004 | 
     DCL05-C. Use typedefs of non-pointer types only
     |
| C5005 | 
     INT05-C. Do not use input functions to convert character data if they cannot handle all possible inputs
     |
| C5007 | 
     STR06-C. Do not assume that strtok() leaves the parse string unchanged
     |
| C5008 | 
     STR07-C. Use the bounds-checking interfaces for string manipulation
     |
| C5009 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| C5010 | 
     MEM03-C. Clear sensitive information stored in reusable resources
     |
| C5011 | 
     FIO01-C. Be careful using functions that use file names for identification
     |
| C5012 | 
     FIO03-C. Do not make assumptions about fopen() and file creation
     |
| C5013 | 
     FIO06-C. Create files with appropriate access permissions
     |
| C5014 | 
     FIO08-C. Take care when calling remove() on an open file
     |
| C5015 | 
     FIO10-C. Take care when using the rename() function
     |
| C5016 | 
     FIO21-C. Do not create temporary files in shared directories
     |
| C5017 | 
     ENV03-C. Sanitize the environment when invoking external programs
     |
| C5018 | 
     ENV33-C. Do not call system()
     |
| C5019 | 
     SIG00-C. Mask signals handled by noninterruptible signal handlers
     |
| C5020 | 
     SIG01-C. Understand implementation-specific details regarding signal handler persistence
     |
| C5021 | 
     SIG34-C. Do not call signal() from within interruptible signal handlers
     |
| C5021 | 
     CON37-C. Do not call signal() in a multithreaded program
     |
| C5022 | 
     MSC30-C. Do not use the rand() function for generating pseudorandom numbers
     |
| C5024 | 
     POS34-C. Do not call putenv() with a pointer to an automatic variable as the argument
     |
| C5025 | 
     FLP32-C. Prevent or detect domain and range errors in math functions
     |
| C5026 | 
     FLP37-C. Do not use object representations to compare floating-point values
     |
| C5027 | 
     MEM36-C. Do not modify the alignment of objects by calling realloc()
     |
| C5028 | 
     FIO38-C. Do not copy a FILE object
     |
| C5030 | 
     ERR34-C. Detect errors when converting a string to a number
     |
| C5031 | 
     MSC32-C. Properly seed pseudorandom number generators
     |
| C5032 | 
     MSC33-C. Do not pass invalid data to the asctime() function
     |
| C5033 | 
     POS30-C. Use the readlink() function properly
     |
| C5034 | 
     POS44-C. Do not use signals to terminate threads
     |
| C5035 | 
     POS47-C. Do not use threads that can be canceled asynchronously
     |
| C5036 | 
     FIO41-C. Do not call getc(), putc(), getwc(), or putwc() with a stream argument that has side effects
     |
| C5037 | 
     CON33-C. Avoid race conditions when using library functions
     |
| C5038 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| C++0064 | 
     PRE30-C. Do not create a universal character name through concatenation
     |
| C++0080 | 
     PRE30-C. Do not create a universal character name through concatenation
     |
| C++0145 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| C++0403 | 
     EXP37-C. Call functions with the correct number and type of arguments
     |
| C++0403 | 
     STR38-C. Do not confuse narrow and wide character strings and functions
     |
| C++1072 | 
     PRE32-C. Do not use preprocessor directives in invocations of function-like macros
     |
| C++1510 | 
     DCL40-C. Do not create incompatible declarations of the same function or object
     |
| C++1765 | 
     CON43-C. Do not allow data races in multithreaded code
     |
| C++1766 | 
     CON43-C. Do not allow data races in multithreaded code
     |
| C++1769 | 
     POS53-C. Do not use more than one mutex for concurrent waiting operations on a condition variable
     |
| C++1770 | 
     CON43-C. Do not allow data races in multithreaded code
     |
| C++1771 | 
     CON43-C. Do not allow data races in multithreaded code
     |
| C++2515 | 
     DCL30-C. Declare objects with appropriate storage durations
     |
| C++2516 | 
     DCL30-C. Declare objects with appropriate storage durations
     |
| C++2527 | 
     DCL30-C. Declare objects with appropriate storage durations
     |
| C++2528 | 
     DCL30-C. Declare objects with appropriate storage durations
     |
| C++2676 | 
     FIO34-C. Distinguish between characters read from a file and EOF or WEOF
     |
| C++2678 | 
     FIO34-C. Distinguish between characters read from a file and EOF or WEOF
     |
| C++2790 | 
     INT34-C. Do not shift an expression by a negative number of bits or by greater than or equal to the number of bits that exist in the operand
     |
| C++2800 | 
     INT32-C. Ensure that operations on signed integers do not result in overflow
     |
| C++2830 | 
     INT33-C. Ensure that division and remainder operations do not result in divide-by-zero errors
     |
| C++2850 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C++2855 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C++2860 | 
     INT32-C. Ensure that operations on signed integers do not result in overflow
     |
| C++2890 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C++2895 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C++2900 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C++2905 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C++2910 | 
     INT30-C. Ensure that unsigned integer operations do not wrap
     |
| C++3000 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C++3001 | 
     FIO34-C. Distinguish between characters read from a file and EOF or WEOF
     |
| C++3003 | 
     INT34-C. Do not shift an expression by a negative number of bits or by greater than or equal to the number of bits that exist in the operand
     |
| C++3010 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| C++3010 | 
     FIO34-C. Distinguish between characters read from a file and EOF or WEOF
     |
| C++3011 | 
     FLP34-C. Ensure that floating-point conversions are within range of the new type
     |
| C++3011 | 
     FLP36-C. Preserve precision when converting integral values to floating-point type
     |
| C++3017 | 
     EXP39-C. Do not access a variable through a pointer of an incompatible type
     |
| C++3030 | 
     EXP39-C. Do not access a variable through a pointer of an incompatible type
     |
| C++3033 | 
     EXP36-C. Do not cast pointers into more strictly aligned pointer types
     |
| C++3033 | 
     EXP39-C. Do not access a variable through a pointer of an incompatible type
     |
| C++3038 | 
     EXP36-C. Do not cast pointers into more strictly aligned pointer types
     |
| C++3040 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C++3041 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C++3042 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C++3043 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C++3044 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C++3045 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C++3046 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C++3047 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C++3048 | 
     INT36-C. Converting a pointer to integer or integer to pointer
     |
| C++3051 | 
     STR34-C. Cast characters to unsigned char before converting to larger integer sizes
     |
| C++3051 | 
     STR37-C. Arguments to character-handling functions must be representable as an unsigned char
     |
| C++3051 | 
     FIO34-C. Distinguish between characters read from a file and EOF or WEOF
     |
| C++3063 | 
     STR30-C. Do not attempt to modify string literals
     |
| C++3064 | 
     STR30-C. Do not attempt to modify string literals
     |
| C++3113 | 
     FIO38-C. Do not copy a FILE object
     |
| C++3114 | 
     FIO38-C. Do not copy a FILE object
     |
| C++3115 | 
     INT35-C. Use correct integer precisions
     |
| C++3118 | 
     FLP37-C. Do not use object representations to compare floating-point values
     |
| C++3127 | 
     MSC38-C. Do not treat a predefined identifier as an object if it might only be implemented as a macro
     |
| C++3137 | 
     FIO34-C. Distinguish between characters read from a file and EOF or WEOF
     |
| C++3146 | 
     MSC39-C. Do not call va_arg() on a va_list that has an indeterminate value
     |
| C++3147 | 
     MSC39-C. Do not call va_arg() on a va_list that has an indeterminate value
     |
| C++3148 | 
     MSC39-C. Do not call va_arg() on a va_list that has an indeterminate value
     |
| C++3149 | 
     MSC39-C. Do not call va_arg() on a va_list that has an indeterminate value
     |
| C++3150 | 
     FIO47-C. Use valid format strings
     |
| C++3151 | 
     FIO47-C. Use valid format strings
     |
| C++3152 | 
     FIO47-C. Use valid format strings
     |
| C++3153 | 
     FIO47-C. Use valid format strings
     |
| C++3154 | 
     FIO47-C. Use valid format strings
     |
| C++3155 | 
     FIO47-C. Use valid format strings
     |
| C++3156 | 
     FIO47-C. Use valid format strings
     |
| C++3157 | 
     FIO47-C. Use valid format strings
     |
| C++3158 | 
     FIO47-C. Use valid format strings
     |
| C++3159 | 
     FIO47-C. Use valid format strings
     |
| C++3167 | 
     MSC39-C. Do not call va_arg() on a va_list that has an indeterminate value
     |
| C++3171 | 
     CON40-C. Do not refer to an atomic variable twice in an expression
     |
| C++3172 | 
     ERR30-C. Take care when reading errno
     |
| C++3173 | 
     ERR30-C. Take care when reading errno
     |
| C++3174 | 
     ERR30-C. Take care when reading errno
     |
| C++3175 | 
     ERR30-C. Take care when reading errno
     |
| C++3176 | 
     ERR30-C. Take care when reading errno
     |
| C++3177 | 
     ERR30-C. Take care when reading errno
     |
| C++3178 | 
     ERR30-C. Take care when reading errno
     |
| C++3179 | 
     ERR30-C. Take care when reading errno
     |
| C++3183 | 
     ERR30-C. Take care when reading errno
     |
| C++3184 | 
     ERR30-C. Take care when reading errno
     |
| C++3225 | 
     PRE31-C. Avoid side effects in arguments to unsafe macros
     |
| C++3225 | 
     FIO41-C. Do not call getc(), putc(), getwc(), or putwc() with a stream argument that has side effects
     |
| C++3226 | 
     PRE31-C. Avoid side effects in arguments to unsafe macros
     |
| C++3227 | 
     PRE31-C. Avoid side effects in arguments to unsafe macros
     |
| C++3228 | 
     PRE31-C. Avoid side effects in arguments to unsafe macros
     |
| C++3229 | 
     PRE31-C. Avoid side effects in arguments to unsafe macros
     |
| C++3229 | 
     FIO41-C. Do not call getc(), putc(), getwc(), or putwc() with a stream argument that has side effects
     |
| C++3337 | 
     MEM31-C. Free dynamically allocated memory when no longer needed
     |
| C++3338 | 
     MEM31-C. Free dynamically allocated memory when no longer needed
     |
| C++3339 | 
     MEM30-C. Do not access freed memory
     |
| C++3605 | 
     STR30-C. Do not attempt to modify string literals
     |
| C++3606 | 
     STR30-C. Do not attempt to modify string literals
     |
| C++3607 | 
     STR30-C. Do not attempt to modify string literals
     |
| C++3705 | 
     ARR37-C. Do not add or subtract an integer to a pointer to a non-array object
     |
| C++3706 | 
     ARR37-C. Do not add or subtract an integer to a pointer to a non-array object
     |
| C++3707 | 
     ARR37-C. Do not add or subtract an integer to a pointer to a non-array object
     |
| C++3709 | 
     EXP46-C. Do not use a bitwise operator with a Boolean-like operand
     |
| C++3717 | 
     FIO34-C. Distinguish between characters read from a file and EOF or WEOF
     |
| C++3802 | 
     ERR33-C. Detect and handle standard library errors
     |
| C++3803 | 
     ERR33-C. Detect and handle standard library errors
     |
| C++3804 | 
     ERR33-C. Detect and handle standard library errors
     |
| C++3807 | 
     EXP35-C. Do not modify objects with temporary lifetime
     |
| C++3808 | 
     EXP35-C. Do not modify objects with temporary lifetime
     |
| C++3842 | 
     MSC41-C. Never hard code sensitive information
     |
| C++3854 | 
     SIG31-C. Do not access shared objects in signal handlers
     |
| C++3855 | 
     SIG31-C. Do not access shared objects in signal handlers
     |
| C++4022 | 
     MSC37-C. Ensure that control never reaches the end of a non-void function
     |
| C++4026 | 
     DCL30-C. Declare objects with appropriate storage durations
     |
| C++4071 | 
     EXP45-C. Do not perform assignments in selection statements
     |
| C++4074 | 
     EXP45-C. Do not perform assignments in selection statements
     |
| C++4122 | 
     MSC40-C. Do not violate constraints
     |
| C++4150 | 
     CON40-C. Do not refer to an atomic variable twice in an expression
     |
| C++4234 | 
     FLP30-C. Do not use floating-point variables as loop counters
     |
| C++4303 | 
     MEM30-C. Do not access freed memory
     |
| C++4304 | 
     MEM30-C. Do not access freed memory
     |
| C++4624 | 
     DCL30-C. Declare objects with appropriate storage durations
     |
| C++4629 | 
     DCL30-C. Declare objects with appropriate storage durations
     |
| C++5009 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| C++5016 | 
     ERR34-C. Detect errors when converting a string to a number
     |
| C++5021 | 
     CON33-C. Avoid race conditions when using library functions
     |
| C++5022 | 
     SIG34-C. Do not call signal() from within interruptible signal handlers
     |
| C++5022 | 
     CON37-C. Do not call signal() in a multithreaded program
     |
| C++5023 | 
     CON41-C. Wrap functions that can fail spuriously in a loop
     |
| C++5029 | 
     MSC30-C. Do not use the rand() function for generating pseudorandom numbers
     |
| C++5030 | 
     MSC33-C. Do not pass invalid data to the asctime() function
     |
| C++5031 | 
     ENV33-C. Do not call system()
     |
| C++5033 | 
     FLP32-C. Prevent or detect domain and range errors in math functions
     |
| C++5034 | 
     MEM36-C. Do not modify the alignment of objects by calling realloc()
     |
| C++5036 | 
     MSC32-C. Properly seed pseudorandom number generators
     |
| C++5038 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| C++5039 | 
     MSC38-C. Do not treat a predefined identifier as an object if it might only be implemented as a macro
     |
| DF2668 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| DF2669 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| DF2681 | 
     ENV34-C. Do not store pointers returned by certain functions
     |
| DF2682 | 
     ENV34-C. Do not store pointers returned by certain functions
     |
| DF2683 | 
     ENV34-C. Do not store pointers returned by certain functions
     |
| DF2696 | 
     FIO46-C. Do not access a closed file
     |
| DF2697 | 
     FIO46-C. Do not access a closed file
     |
| DF2698 | 
     FIO46-C. Do not access a closed file
     |
| DF2701 | 
     FIO42-C. Close files when they are no longer needed
     |
| DF2702 | 
     FIO42-C. Close files when they are no longer needed
     |
| DF2703 | 
     FIO42-C. Close files when they are no longer needed
     |
| DF2706 | 
     MEM31-C. Free dynamically allocated memory when no longer needed
     |
| DF2707 | 
     MEM31-C. Free dynamically allocated memory when no longer needed
     |
| DF2708 | 
     MEM31-C. Free dynamically allocated memory when no longer needed
     |
| DF2721 | 
     MEM34-C. Only free memory allocated dynamically
     |
| DF2722 | 
     MEM34-C. Only free memory allocated dynamically
     |
| DF2723 | 
     MEM34-C. Only free memory allocated dynamically
     |
| DF2726 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2727 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2728 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2761 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| DF2762 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| DF2763 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| DF2766 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| DF2767 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| DF2768 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| DF2771 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| DF2772 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| DF2773 | 
     ARR36-C. Do not subtract or compare two pointers that do not refer to the same array
     |
| DF2791 | 
     INT34-C. Do not shift an expression by a negative number of bits or by greater than or equal to the number of bits that exist in the operand
     |
| DF2792 | 
     INT34-C. Do not shift an expression by a negative number of bits or by greater than or equal to the number of bits that exist in the operand
     |
| DF2793 | 
     INT34-C. Do not shift an expression by a negative number of bits or by greater than or equal to the number of bits that exist in the operand
     |
| DF2794 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2801 | 
     INT32-C. Ensure that operations on signed integers do not result in overflow
     |
| DF2801 | 
     INT08-C. Verify that all integer values are in range
     |
| DF2802 | 
     INT32-C. Ensure that operations on signed integers do not result in overflow
     |
| DF2802 | 
     INT08-C. Verify that all integer values are in range
     |
| DF2803 | 
     INT32-C. Ensure that operations on signed integers do not result in overflow
     |
| DF2803 | 
     INT08-C. Verify that all integer values are in range
     |
| DF2804 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2810 | 
     EXP34-C. Do not dereference null pointers
     |
| DF2811 | 
     EXP34-C. Do not dereference null pointers
     |
| DF2812 | 
     EXP34-C. Do not dereference null pointers
     |
| DF2813 | 
     EXP34-C. Do not dereference null pointers
     |
| DF2820 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2820 | 
     ERR33-C. Detect and handle standard library errors
     |
| DF2821 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2821 | 
     ERR33-C. Detect and handle standard library errors
     |
| DF2822 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2822 | 
     ERR33-C. Detect and handle standard library errors
     |
| DF2823 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2823 | 
     ERR33-C. Detect and handle standard library errors
     |
| DF2824 | 
     ERR33-C. Detect and handle standard library errors
     |
| DF2831 | 
     INT33-C. Ensure that division and remainder operations do not result in divide-by-zero errors
     |
| DF2832 | 
     INT33-C. Ensure that division and remainder operations do not result in divide-by-zero errors
     |
| DF2833 | 
     INT33-C. Ensure that division and remainder operations do not result in divide-by-zero errors
     |
| DF2835 | 
     STR32-C. Do not pass a non-null-terminated character sequence to a library function that expects a string
     |
| DF2836 | 
     STR32-C. Do not pass a non-null-terminated character sequence to a library function that expects a string
     |
| DF2839 | 
     STR32-C. Do not pass a non-null-terminated character sequence to a library function that expects a string
     |
| DF2840 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2840 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2840 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2840 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| DF2841 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2841 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2841 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2841 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| DF2842 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2842 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2842 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2842 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| DF2843 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2843 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2843 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2843 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| DF2845 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2845 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2846 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2846 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2847 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2847 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2848 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2848 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2851 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2852 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2853 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2854 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2856 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2857 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2858 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2859 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2861 | 
     INT32-C. Ensure that operations on signed integers do not result in overflow
     |
| DF2862 | 
     INT32-C. Ensure that operations on signed integers do not result in overflow
     |
| DF2863 | 
     INT32-C. Ensure that operations on signed integers do not result in overflow
     |
| DF2864 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2877 | 
     MSC07-C. Detect and remove dead code
     |
| DF2880 | 
     MSC07-C. Detect and remove dead code
     |
| DF2881 | 
     MSC07-C. Detect and remove dead code
     |
| DF2882 | 
     MSC07-C. Detect and remove dead code
     |
| DF2883 | 
     MSC07-C. Detect and remove dead code
     |
| DF2888 | 
     MSC37-C. Ensure that control never reaches the end of a non-void function
     |
| DF2891 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2892 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2893 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2894 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2896 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2897 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2898 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2899 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2901 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2902 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2903 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2904 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2906 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2907 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2908 | 
     INT31-C. Ensure that integer conversions do not result in lost or misinterpreted data
     |
| DF2909 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2911 | 
     INT30-C. Ensure that unsigned integer operations do not wrap
     |
| DF2911 | 
     INT08-C. Verify that all integer values are in range
     |
| DF2912 | 
     INT30-C. Ensure that unsigned integer operations do not wrap
     |
| DF2912 | 
     INT08-C. Verify that all integer values are in range
     |
| DF2913 | 
     INT30-C. Ensure that unsigned integer operations do not wrap
     |
| DF2913 | 
     INT08-C. Verify that all integer values are in range
     |
| DF2914 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2924 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2930 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2930 | 
     ARR37-C. Do not add or subtract an integer to a pointer to a non-array object
     |
| DF2930 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2930 | 
     ERR33-C. Detect and handle standard library errors
     |
| DF2931 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2931 | 
     ARR37-C. Do not add or subtract an integer to a pointer to a non-array object
     |
| DF2931 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2931 | 
     ERR33-C. Detect and handle standard library errors
     |
| DF2932 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2932 | 
     ARR37-C. Do not add or subtract an integer to a pointer to a non-array object
     |
| DF2932 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2932 | 
     ERR33-C. Detect and handle standard library errors
     |
| DF2933 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2933 | 
     ARR37-C. Do not add or subtract an integer to a pointer to a non-array object
     |
| DF2933 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2933 | 
     ERR33-C. Detect and handle standard library errors
     |
| DF2934 | 
     ERR33-C. Detect and handle standard library errors
     |
| DF2935 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2935 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2935 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2935 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| DF2936 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2936 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2936 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2936 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| DF2937 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2937 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2937 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2937 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| DF2938 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2938 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF2938 | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| DF2938 | 
     MEM35-C. Allocate sufficient memory for an object
     |
| DF2941 | 
     INT16-C. Do not make assumptions about representation of signed integers
     |
| DF2942 | 
     INT16-C. Do not make assumptions about representation of signed integers
     |
| DF2943 | 
     INT16-C. Do not make assumptions about representation of signed integers
     |
| DF2944 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2946 | 
     INT16-C. Do not make assumptions about representation of signed integers
     |
| DF2947 | 
     INT16-C. Do not make assumptions about representation of signed integers
     |
| DF2948 | 
     INT16-C. Do not make assumptions about representation of signed integers
     |
| DF2949 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2950 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2951 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2952 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2953 | 
     ARR30-C. Do not form or use out-of-bounds pointers or array subscripts
     |
| DF2954 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2956 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2959 | 
     INT04-C. Enforce limits on integer values originating from tainted sources
     |
| DF2961 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2962 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2963 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2966 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2967 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2968 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2971 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2972 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2973 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2976 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2977 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2978 | 
     EXP33-C. Do not read uninitialized memory
     |
| DF2980 | 
     MSC07-C. Detect and remove dead code
     |
| DF2980 | 
     MSC13-C. Detect and remove unused values
     |
| DF2981 | 
     MSC07-C. Detect and remove dead code
     |
| DF2981 | 
     MSC13-C. Detect and remove unused values
     |
| DF2982 | 
     MSC07-C. Detect and remove dead code
     |
| DF2982 | 
     MSC13-C. Detect and remove unused values
     |
| DF2983 | 
     MSC07-C. Detect and remove dead code
     |
| DF2983 | 
     MSC13-C. Detect and remove unused values
     |
| DF2984 | 
     MSC07-C. Detect and remove dead code
     |
| DF2984 | 
     MSC13-C. Detect and remove unused values
     |
| DF2985 | 
     MSC07-C. Detect and remove dead code
     |
| DF2985 | 
     MSC13-C. Detect and remove unused values
     |
| DF2986 | 
     MSC07-C. Detect and remove dead code
     |
| DF2986 | 
     MSC13-C. Detect and remove unused values
     |
| DF4711 | 
     FIO39-C. Do not alternately input and output from a stream without an intervening flush or positioning call
     |
| DF4712 | 
     FIO39-C. Do not alternately input and output from a stream without an intervening flush or positioning call
     |
| DF4713 | 
     FIO39-C. Do not alternately input and output from a stream without an intervening flush or positioning call
     |
| DF4726 | 
     EXP42-C. Do not compare padding data
     |
| DF4727 | 
     EXP42-C. Do not compare padding data
     |
| DF4728 | 
     EXP42-C. Do not compare padding data
     |
| DF4729 | 
     EXP42-C. Do not compare padding data
     |
| DF4751 | 
     ENV30-C. Do not modify the object referenced by the return value of certain functions
     |
| DF4752 | 
     ENV30-C. Do not modify the object referenced by the return value of certain functions
     |
| DF4753 | 
     ENV30-C. Do not modify the object referenced by the return value of certain functions
     |
| DF4781 | 
     ERR32-C. Do not rely on indeterminate values of errno
     |
| DF4782 | 
     ERR32-C. Do not rely on indeterminate values of errno
     |
| DF4783 | 
     ERR32-C. Do not rely on indeterminate values of errno
     |
| DF4841 | 
     FIO44-C. Only use values for fsetpos() that are returned from fgetpos()
     |
| DF4842 | 
     FIO44-C. Only use values for fsetpos() that are returned from fgetpos()
     |
| DF4843 | 
     FIO44-C. Only use values for fsetpos() that are returned from fgetpos()
     |
| DF4846 | 
     SIG35-C. Do not return from a computational exception signal handler
     |
| DF4847 | 
     SIG35-C. Do not return from a computational exception signal handler
     |
| DF4848 | 
     SIG35-C. Do not return from a computational exception signal handler
     |
| DF4851 | 
     FIO45-C. Avoid TOCTOU race conditions while accessing files
     |
| DF4852 | 
     FIO45-C. Avoid TOCTOU race conditions while accessing files
     |
| DF4853 | 
     FIO45-C. Avoid TOCTOU race conditions while accessing files
     |
| DF4856 | 
     ENV32-C. All exit handlers must return normally
     |
| DF4857 | 
     ENV32-C. All exit handlers must return normally
     |
| DF4858 | 
     ENV32-C. All exit handlers must return normally
     |
| DF4861 | 
     FIO40-C. Reset strings on fgets()  or fgetws() failure
     |
| DF4862 | 
     FIO40-C. Reset strings on fgets()  or fgetws() failure
     |
| DF4863 | 
     FIO40-C. Reset strings on fgets()  or fgetws() failure
     |
| DF4866 | 
     MEM30-C. Do not access freed memory
     |
| DF4867 | 
     MEM30-C. Do not access freed memory
     |
| DF4868 | 
     MEM30-C. Do not access freed memory
     |
| DF4871 | 
     MEM30-C. Do not access freed memory
     |
| DF4872 | 
     MEM30-C. Do not access freed memory
     |
| DF4873 | 
     MEM30-C. Do not access freed memory
     |
| DF4876 | 
     POS37-C. Ensure that privilege relinquishment is successful
     |
| DF4877 | 
     POS37-C. Ensure that privilege relinquishment is successful
     |
| DF4878 | 
     POS37-C. Ensure that privilege relinquishment is successful
     |
| DF4880 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF4881 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF4882 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF4883 | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |
| DF4886 | 
     POS35-C. Avoid race conditions while checking for the existence of a symbolic link
     |
| DF4887 | 
     POS35-C. Avoid race conditions while checking for the existence of a symbolic link
     |
| DF4888 | 
     POS35-C. Avoid race conditions while checking for the existence of a symbolic link
     |
| DF4891 | 
     POS36-C. Observe correct revocation order while relinquishing privileges
     |
| DF4892 | 
     POS36-C. Observe correct revocation order while relinquishing privileges
     |
| DF4893 | 
     POS36-C. Observe correct revocation order while relinquishing privileges
     |
| DF4901 | 
     EXP47-C. Do not call va_arg with an argument of the incorrect type
     |
| DF4902 | 
     EXP47-C. Do not call va_arg with an argument of the incorrect type
     |
| DF4903 | 
     EXP47-C. Do not call va_arg with an argument of the incorrect type
     |
| DF4904 | 
     EXP47-C. Do not call va_arg with an argument of the incorrect type
     |
| DF4906 | 
     POS39-C. Use the correct byte ordering when transferring data between systems
     |
| DF4907 | 
     POS39-C. Use the correct byte ordering when transferring data between systems
     |
| DF4908 | 
     POS39-C. Use the correct byte ordering when transferring data between systems
     |
| DF4911 | 
     FIO37-C. Do not assume that fgets() or fgetws() returns a nonempty string when successful
     |
| DF4912 | 
     FIO37-C. Do not assume that fgets() or fgetws() returns a nonempty string when successful
     |
| DF4913 | 
     FIO37-C. Do not assume that fgets() or fgetws() returns a nonempty string when successful
     |
| DF4916 | 
     FIO30-C. Exclude user input from format strings
     |
| DF4917 | 
     FIO30-C. Exclude user input from format strings
     |
| DF4918 | 
     FIO30-C. Exclude user input from format strings
     |
| DF4921 | 
     FIO32-C. Do not perform operations on devices that are only appropriate for files
     |
| DF4922 | 
     FIO32-C. Do not perform operations on devices that are only appropriate for files
     |
| DF4923 | 
     FIO32-C. Do not perform operations on devices that are only appropriate for files
     |
| DF4926 | 
     CON34-C. Declare objects shared between threads with appropriate storage durations
     |
| DF4926 | 
     POS50-C. Declare objects shared between POSIX threads with appropriate storage durations
     |
| DF4927 | 
     CON34-C. Declare objects shared between threads with appropriate storage durations
     |
| DF4927 | 
     POS50-C. Declare objects shared between POSIX threads with appropriate storage durations
     |
| DF4928 | 
     CON34-C. Declare objects shared between threads with appropriate storage durations
     |
| DF4928 | 
     POS50-C. Declare objects shared between POSIX threads with appropriate storage durations
     |
| DF4941 | 
     DCL39-C. Avoid information leakage when passing a structure across a trust boundary
     |
| DF4942 | 
     DCL39-C. Avoid information leakage when passing a structure across a trust boundary
     |
| DF4943 | 
     DCL39-C. Avoid information leakage when passing a structure across a trust boundary
     |
| DF4951 | 
     POS38-C. Beware of race conditions when using fork and file descriptors
     |
| DF4952 | 
     POS38-C. Beware of race conditions when using fork and file descriptors
     |
| DF4955 | 
     ARR39-C. Do not add or subtract a scaled integer to a pointer
     |
| DF4956 | 
     ARR39-C. Do not add or subtract a scaled integer to a pointer
     |
| DF4957 | 
     ARR39-C. Do not add or subtract a scaled integer to a pointer
     |
| DF4961 | 
     CON31-C. Do not destroy a mutex while it is locked
     |
| DF4962 | 
     CON31-C. Do not destroy a mutex while it is locked
     |
| DF4966 | 
     POS52-C. Do not perform operations that can block while holding a POSIX lock
     |
| DF4967 | 
     POS52-C. Do not perform operations that can block while holding a POSIX lock
     |
| DF4971 | 
     POS48-C. Do not unlock or destroy another POSIX thread's mutex
     |
| DF4972 | 
     POS48-C. Do not unlock or destroy another POSIX thread's mutex
     |
| DF4976 | 
     CON33-C. Avoid race conditions when using library functions
     |
| DF4977 | 
     CON33-C. Avoid race conditions when using library functions
     |
| DF4981 | 
     POS48-C. Do not unlock or destroy another POSIX thread's mutex
     |
| DF4982 | 
     POS48-C. Do not unlock or destroy another POSIX thread's mutex
     |
| DF4991 | 
     ENV31-C. Do not rely on an environment pointer following an operation that may invalidate it
     |
| DF4992 | 
     ENV31-C. Do not rely on an environment pointer following an operation that may invalidate it
     |
| DF4993 | 
     ENV31-C. Do not rely on an environment pointer following an operation that may invalidate it
     |

## Comments:
<table data-border="0" width="100%">
<colgroup>
<col style="width: 100%" />
</colgroup>
<tbody>
<tr>
<td><p>Hello,</p>
<p>The below QAC messages are not enforced by QAC but by CERT CCM. Are the below warnings are supported in MISRA?</p>
<div class="table-wrap">
<pre class="table"><code>|  |
| ----|
| 5018 |
| 5031 |
| 5032 |
| 5033 |
| 5035 |
| 5009 |
| 5038 |</code></pre>
</div>
<p>Please support.</p>
<p>Regards</p>
<p>Vijayanand B</p>
<div class="smallfont" data-align="left" style="color: #666666; width: 98%; margin-bottom: 10px;">
<img src="images/icons/contenttypes/comment_16.png" /> Posted by vijay.anand2 at May 23, 2022 04:06
</div></td>
</tr>
<tr>
<td style="border-top: 1px dashed #666666"><p>Hello Vijayanand</p>
<p>As you say, the messages you list are specific to the CERT CCM.  There are messages of this type (ie numbered 5000 and above) that are specific to MISRA, but they are not the same in both CMs.  They are 'secondary analysis' messages which are tailored to a particular rule in a specific standard</p>
<p><br />
</p>
<p>Best regards</p>
<p>Jill</p>
<div class="smallfont" data-align="left" style="color: #666666; width: 98%; margin-bottom: 10px;">
<img src="images/icons/contenttypes/comment_16.png" /> Posted by jill_britton at May 25, 2022 03:47
</div></td>
</tr>
</tbody>
</table>
