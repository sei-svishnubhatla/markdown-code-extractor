> [!info]  
>
> This page was automatically generated and should not be edited.
>
> The information on this page was provided by outside contributors and has not been verified by SEI CERT.


| CERT Rule | Related Guidelines |
| ----|----|
| INT36-C | CWE-119, Improper Restriction of Operations within the Bounds of a Memory Buffer |
| INT36-C | CWE-466, Return of Pointer Value Outside of Expected Range |
| ARR38-C | CWE-129, Improper Validation of Array Index |

