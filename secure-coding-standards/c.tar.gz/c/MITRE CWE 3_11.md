> [!info]  
>
> This page was automatically generated and should not be edited.
>
> The information on this page was provided by outside contributors and has not been verified by SEI CERT.


| CERT Rule | Related Guidelines |
| ----|----|
| ARR36-C | CWE-469, Use of Pointer Subtraction to Determine Size |

