> [!warning]  
>
> This page was automatically generated and should not be edited.
> [!warning]  
>
> The information on this page was provided by outside contributors and has not been verified by SEI CERT.
> [!info]  
>
> The table below can be re-ordered, by clicking column headers.

**Tool Version:** unknown

| 
    Checker
    | 
    Guideline
    |
| ----|----|
|  | 
     STR31-C. Guarantee that storage for strings has sufficient space for character data and the null terminator
     |
| Can detect violations of this rule with CERT C Rule Pack | 
     ARR38-C. Guarantee that library functions do not form invalid pointers
     |

