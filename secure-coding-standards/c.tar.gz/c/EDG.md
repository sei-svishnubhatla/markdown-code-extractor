> [!warning]  
>
> This page was automatically generated and should not be edited.
> [!warning]  
>
> The information on this page was provided by outside contributors and has not been verified by SEI CERT.
> [!info]  
>
> The table below can be re-ordered, by clicking column headers.

**Tool Version:** unknown

| 
    Checker
    | 
    Guideline
    |
| ----|----|
|  | 
     EXP36-C. Do not cast pointers into more strictly aligned pointer types
     |
|  | 
     EXP37-C. Call functions with the correct number and type of arguments
     |
|  | 
     STR04-C. Use plain char for characters in the basic character set
     |

